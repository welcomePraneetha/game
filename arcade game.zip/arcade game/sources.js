(function() {
    var resourceCache = {};
    var loading = [];
    var readyCallbacks = [];

    function load(urlOrArr) {
        if(urlOrArr instanceof Array) {
            //call image loader on that image file
            urlOrArr.forEach(function(url) {
                _load(url);
            });
        } else {
           //call image loader directly
            _load(urlOrArr);
        }
    }

    function _load(url) {
        if(resourceCache[url]) {
            //return image
            return resourceCache[url];
        } else {
            var img = new Image();
            img.onload = function() {
                
                resourceCache[url] = img;

                /* Once the image is actually loaded and properly cached,
                 * call all of the onReady() callbacks we have defined.
                 */
                if(isReady()) {
                    readyCallbacks.forEach(function(func) { func(); });
                }
            };

            resourceCache[url] = false;
            img.src = url;
        }
    }

    function get(url) {
        return resourceCache[url];
    }

    //determines all images loaded perfectly or not
    function isReady() {
        var ready = true;
        for(var k in resourceCache) {
            if(resourceCache.hasOwnProperty(k) &&
               !resourceCache[k]) {
                ready = false;
            }
        }
        return ready;
    }

   //add function to call back stack when images loaded properly
    function onReady(func) {
        readyCallbacks.push(func);
    }

//publicly accessable functions
    window.Resources = {
        load: load,
        get: get,
        onReady: onReady,
        isReady: isReady
    };
})();