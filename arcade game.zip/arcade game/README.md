# Project : CLASSIC ARCADE GAME CLONE

## Contents

This file has five main sub-files:
1. game.html which has the html code.
2. game.css which has the code for styling.
3. game.js which has the for functionality of the project.
4. sources.js which has the properties for loading the images.
5. engine.js which has the functionality for operation of game.


## Dependencies
* The HTML code runs on the basis of the three js codes:`sources.js`,`main.js`,`game.js`

## Instructions to play the game:
Save the code and run it in any of the browsers.When you click ENTER button the game starts. the players has to move from grass block to water block. The score and difficulty increases every time the player reaches the water block.To increse lives the player has to collect hearts.
