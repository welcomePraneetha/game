var Engine = (function(global) {
    //pre defining the variables
    var doc = global.document,
        win = global.window,
        canvas = doc.createElement('canvas'),
        ctx = canvas.getContext('2d'),
        lastTime;

    canvas.width = 505;
    canvas.height = 606;
    doc.body.appendChild(canvas);

    var currentGameState = "startGame";


    function main() {
        var now = Date.now(),
            dt = (now - lastTime) / 1000.0;

        //calling update and render functions
        update(dt);
        render();

        //lastTime is used to set time delta
        lastTime = now;

        win.requestAnimationFrame(main);
    }

    //intialization setup
    function init() {
        lastTime = Date.now();
        main();
    }

    function update(dt) {

        switch (currentGameState) {
            case "startGame":
                document.removeEventListener("keyup", input);
                var startInput = function(e) {
                    var key = e.which || e.keyCode;
                    if (key === 13) {
                        currentGameState = "inGame";
                    }
                };
                document.addEventListener("keydown", startInput);
                break;

            case "inGame":
                document.addEventListener('keyup', input);
                updateEntities(dt);
                ctx.clearRect(0,0,canvas.width,canvas.height);
                break;

            case "gameOver":
                document.removeEventListener('keyup', input);
                var gameoverInput = function(e) {
                    var key = e.which || e.keyCode;
                    if (key === 13) {
                        currentGameState = "inGame";
                    }
                };
                document.addEventListener("keydown", gameoverInput);
                break;
        }
    }

   //update entities
    function updateEntities(dt) {
        allEnemies.forEach(function(enemy) {
            enemy.update(dt);
        });
        player.update();
        gem.update();
        Star.update();
    }

    function render() {
    // Render different game states according to each case
    switch (currentGameState) {
        case "startGame":
            // Display an empty game board with text here
            var rowImages = [
                    'images/water.png',
                    'images/stone.jpg',
                    'images/stone.jpg',
                    'images/stone.jpg',
                    'images/grass.jpg',
                    'images/grass.jpg'
                ],
                numRows = 6,
                numCols = 5,
                row, col;

            for (row = 0; row < numRows; row++) {
                for (col = 0; col < numCols; col++) {
                    ctx.drawImage(Resources.get(rowImages[row]), col * 101, row * 101);
                }
            }
            break;

        case "inGame":
            // Draw the actual game board
            rowImages = [
                    'images/water.png',
                    'images/stone.jpg',
                    'images/stone.jpg', 
                    'images/stone.jpg',
                    'images/grass.jpg',
                    'images/grass.jpg' 
                ],
                numRows = 6,
                numCols = 5;

            //loop to draw the correct image for that grid
            for (row = 0; row < numRows; row++) {
                for (col = 0; col < numCols; col++) {
                    ctx.drawImage(Resources.get(rowImages[row]), col * 101, row * 101);
                }
            }
            renderEntities();
            break;

        case "gameOver":
            // Display an empty game board with text here
            rowImages = [
                    'images/water.png',
                    'images/stone.jpg',
                    'images/stone.jpg',
                    'images/stone.jpg',
                    'images/grass.jpg',
                    'images/grass.jpg'
                ],
                numRows = 6,
                numCols = 5;

            for (row = 0; row < numRows; row++) {
                for (col = 0; col < numCols; col++) {
                    ctx.drawImage(Resources.get(rowImages[row]), col * 101, row * 101);
                    // Text to display over the game board
                    ctx.fillStyle = "red";
                    ctx.font = "100px Georgia";
                    ctx.textAlign = "center";
                    ctx.fillText("Game Over!", canvas.width/2, canvas.height/3);
                    ctx.fillStyle = "yellow";
                    ctx.font = "50px Italic";
                    ctx.textAlign = "center";
                    ctx.fillText("Press Enter To Restart", canvas.width/2, canvas.height/2);
                }
            }
            break;
            }
    }

    function renderEntities() {
       //call the render function
        allEnemies.forEach(function(enemy) {
            enemy.render();
        });

        player.render();
        gem.render();
        Star.render();
    }

    //Reset the game
    function reset() {
        currentGameState = "gameOver";
        player.characterReset();
        Star.StarReset();
        clearTimeout(Star.StarWaitTime);
        gem.gemReset();
        clearTimeout(gem.gemWaitTime);
        speedMultiplier = 40;
        player.playerScore = 0;
        player.playerLives = 3;
        allEnemies = [];

        for (var i = 0; i < 3; i++) {
            var startSpeed = speedMultiplier * Math.floor(Math.random() * 10 + 1);
            allEnemies.push(new Enemy(-100, 60 + (85 * i), startSpeed));
        }
    }

    
    //reload the images to reset the game
    Resources.load([
        'images/stone.jpg',
        'images/water.png',
        'images/grass.jpg',
        'images/turtle.png',
        'images/mario.png',
        'images/gem.png',
        'images/Star.png',
        ]);
    Resources.onReady(init);

    //Assign the canvas' context object and the reset function to the global variable 
    global.ctx = ctx;
    global.reset = reset;

})(this);