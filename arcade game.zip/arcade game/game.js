// declartion of enemy
let Enemy = function(x,y,speed) {

    this.x = x;
    this.y = y;
    this.speed = speed;
    // image address of enemy
    this.sprite = 'images/turtle.png'
};

// Update the enemy's position
Enemy.prototype.update = function(dt) {

    this.x = this.x + this.speed * dt;
    // Reset speed of enemy
    this.offScreenX = 505;
    this.startingX = -100;
    if (this.x >= this.offScreenX) {
        this.x = this.startingX;
        this.randomSpeed();
    }
    this.checkCollision();
};

let speedIncreament = 40;

// Random speed generator
Enemy.prototype.randomSpeed = function (){
    this.speed = speedIncreament * Math.floor(Math.random() * 10 + 1);
};

Enemy.prototype.render = function() {
    ctx.drawImage(Resources.get(this.sprite), this.x, this.y);
    ctx.fillStyle = "brown";
    ctx.font = "25px Georgia";
    ctx.fillText("Score: " + player.playerScore, 10, 40);
    ctx.fillText("Lives: " + player.playerLives, 150, 40);
    ctx.fillText("Difficulty: " + speedIncreament, 300, 40);
};


Enemy.prototype.checkCollision = function() {

    var playerBox = {x: player.x, y: player.y, width: 50, height: 40};
    var enemyBox = {x: this.x, y: this.y, width: 60, height: 70};
    if (playerBox.x < enemyBox.x + enemyBox.width &&
        playerBox.x + playerBox.width > enemyBox.x &&
        playerBox.y < enemyBox.y + enemyBox.height &&
        playerBox.height + playerBox.y > enemyBox.y) {
        this.collisionDetected();
    }
};

Enemy.prototype.collisionDetected = function() {
    player.playerLives -= 1;
    player.characterReset();
};


// Gems the player should try to pick up
var Gem = function(x,y) {
    this.x = x;
    this.y = y;
    this.sprite = 'images/gem.png';
    this.gemWaitTime = undefined;
};

// Update gem, call checkCollision
Gem.prototype.update = function() {
    this.checkCollision();
};

// Draw the gem to the screen
Gem.prototype.render = function() {
    ctx.drawImage(Resources.get(this.sprite), this.x, this.y);
};

//Check for collision
Gem.prototype.checkCollision = function() {

    var playerBox = {x: player.x, y: player.y, width: 50, height: 40};
    var gemBox = {x: this.x, y: this.y, width: 60, height: 70};

    if (playerBox.x < gemBox.x + gemBox.width &&
        playerBox.x + playerBox.width > gemBox.x &&
        playerBox.y < gemBox.y + gemBox.height &&
        playerBox.height + playerBox.y > gemBox.y) {
        this.collisionDetected();
    }
};


// Increase player score when collided with gem and reset the gem
Gem.prototype.collisionDetected = function() {
    this.x = 900;
    this.y = 900;
    player.playerScore += 30;
    this.wait();
};


Gem.prototype.wait = function() {
    this.gemWaitTime = setTimeout( function() {
        gem.gemReset();
    }, 5000);
};

// Reset the gem to a new location
Gem.prototype.gemReset = function() {
    
    this.x = (101 * Math.floor(Math.random() * 4) + 0);
    this.y = (60 + (85 * Math.floor(Math.random() * 3) + 0));
};

// Hearts the player should try to pick up
var Star = function(x,y) {
    this.x = x;
    this.y = y;
    this.sprite = 'images/Star.png';
    this.heartWaitTime = undefined;
};

// Update heart, call checkCollision
Star.prototype.update = function() {
    this.checkCollision();
};

// Draw the heart to the screen
Star.prototype.render = function() {
    ctx.drawImage(Resources.get(this.sprite), this.x, this.y);
};

// Check for collision
Star.prototype.checkCollision = function() {

    var playerBox = {x: player.x, y: player.y, width: 50, height: 40};
    var heartBox = {x: this.x, y: this.y, width: 60, height: 70};

    if (playerBox.x < heartBox.x + heartBox.width &&
        playerBox.x + playerBox.width > heartBox.x &&
        playerBox.y < heartBox.y + heartBox.height &&
        playerBox.height + playerBox.y > heartBox.y) {
        this.collisionDetected();
    }
};


// Increment of player lives and reset hearts
Star.prototype.collisionDetected = function() {
    this.x = 900;
    this.y = 900;
    player.playerLives += 1;
    this.wait();
};

Star.prototype.wait = function() {
    this.StarWaitTime = setTimeout( function() {
        Star.StarReset();
    }, 30000);
};

// Reset the heart to a new location
Star.prototype.StarReset = function() {

    this.x = (101 * Math.floor(Math.random() * 4) + 0);
    this.y = (70 + (85 * Math.floor(Math.random() * 3) + 0));
};

//player class
var Player = function() {
    this.startingX = 200;
    this.startingY = 400;
    this.x = this.startingX;
    this.y = this.startingY;
    this.sprite = 'images/mario.png';
    this.playerScore = 0;
    this.playerLives = 3;
};


Player.prototype.update = function() {
    if (this.playerLives === 0) {
    reset();
    }
};

// Resets the player position to the start position
Player.prototype.characterReset = function() {
    this.startingX = 200;
    this.startingY = 400;
    this.x = this.startingX;
    this.y = this.startingY;
};

// Increase score and increase difficulty when player reaches top of water
Player.prototype.success = function() {
    this.playerScore += 20;
    speedIncreament += 5;
    this.characterReset();
};

// Draw the player on the screen, required method for game
Player.prototype.render = function() {
    ctx.drawImage(Resources.get(this.sprite), this.x, this.y);
};

// Move the player according to keys pressed
Player.prototype.handleInput = function(allowedKeys) {
    switch (allowedKeys) {
        case "left":
            if (this.x > 0) {
                this.x -= 101;
            }
            break;

        case "right":
            if (this.x < 402) {
                this.x += 101;
            }
            break;

        case "up":
            if (this.y < 0) {
                this.success();
            } else {
                this.y -= 83;
            }
            break;

        case "down":
            if (this.y < 400) {
                this.y += 83;
            }
            break;
    }
};

// Instantiate player
var player = new Player();

// Empty allEnemies array
var allEnemies = [];

for (var i = 0; i < 3; i++) {
    var startSpeed = speedIncreament * Math.floor(Math.random() * 10 + 1);
    allEnemies.push(new Enemy(-100, 60 + (85 * i), startSpeed));
}

// Instantiate Gem
var gem = new Gem (101 * Math.floor(Math.random() * 4) + 0, 60 +
    (85 * Math.floor(Math.random() * 3) + 0));

// Instantiate heart
var Star = new Star (101 * Math.floor(Math.random() * 4) + 0, 70 +
    (85 * Math.floor(Math.random() * 3) + 0));

//Event listener
var input = function(e) {
    var allowedKeys = {
        37: 'left',
        38: 'up',
        39: 'right',
        40: 'down'
    };
    player.handleInput(allowedKeys[e.keyCode]);
};
document.addEventListener('keyup', input);